CREATE TABLE pessoa (
    idPessoa SERIAL PRIMARY KEY,   -- chave primária auto-increment
    nome VARCHAR(100) NOT NULL,    -- nome da pessoa, obrigatório
    cpf CHAR(11) NOT NULL UNIQUE,  -- CPF com 11 caracteres, único
    data_nasc DATE                 -- data de nascimento
);

CREATE TABLE pet (
    idPet SERIAL PRIMARY KEY,           -- chave primária auto-increment
    idPessoa INT NOT NULL,              -- referência à pessoa dona do pet
    nome VARCHAR(50) NOT NULL,          -- nome do pet
    especie VARCHAR(30),                -- espécie do pet
    raca VARCHAR(30),                   -- raça
    data_nascimento DATE,               -- data de nascimento
    cor VARCHAR(20),                    -- cor
    porte VARCHAR(20),                  -- porte (pequeno, médio, grande)
    CONSTRAINT fk_pessoa FOREIGN KEY (idPessoa) REFERENCES pessoa(idPessoa)
        ON DELETE CASCADE               -- se pessoa for deletada, deleta os pets
);

