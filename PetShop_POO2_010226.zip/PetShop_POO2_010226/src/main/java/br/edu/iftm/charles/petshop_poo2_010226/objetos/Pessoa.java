/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.iftm.charles.petshop_poo2_010226.objetos;

import java.sql.Date;

/**
 *
 * @author charl
 */
public class Pessoa {

    private int idPessoa;
    private String nome;
    private String cpf;
    private Date data_nasc;

    public int getIdPessoa() {
        return idPessoa;
    }

    public void setIdPessoa(int idPessoa) {
        this.idPessoa = idPessoa;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public Date getData_nasc() {
        return data_nasc;
    }



    public void setData_nasc(String data) {
        this.data_nasc = Date.valueOf(data); // formato "yyyy-MM-dd"
    }

}
