/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.iftm.charles.petshop_poo2_010226.dao;

import br.edu.iftm.charles.petshop_poo2_010226.objetos.Pessoa;
import br.edu.iftm.charles.petshop_poo2_010226.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/**
 *
 * @author charl
 */
public class PessoaDAO {
    private Connection conn;
    
    public PessoaDAO(){
        conn = new Conexao().conectar();
    }
    
    public Pessoa salvar(Pessoa p){
        try{
            PreparedStatement stmt = conn.prepareStatement("INSERT INTO pessoa(nome, cpf, data_nasc) values(?, ?, ?)" , Statement.RETURN_GENERATED_KEYS);
            
            stmt.setString(1, p.getNome());
            stmt.setString(2, p.getCpf());
            stmt.setDate(3, p.getData_nasc());
            stmt.execute();
            ResultSet rs = stmt.getGeneratedKeys();
            
            if(rs.next()){
                p.setIdPessoa(rs.getInt("idPessoa"));
            }else{
                p.setIdPessoa(-1);
            }
        }catch(SQLException ex){
            ex.printStackTrace();
        }
        
        return p;
    }
}
