/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package br.edu.iftm.charles.petshop_poo2_010226.dao;

import br.edu.iftm.charles.petshop_poo2_010226.objetos.Pet;
import br.edu.iftm.charles.petshop_poo2_010226.util.Conexao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;



/**
 *
 * @author charl
 */
public class PetDAO {
   private Connection conn;
   
   public PetDAO(){
       conn = new Conexao().conectar();
   }
   
   public Pet Salvar(Pet pet){
       try{
           PreparedStatement stmt = conn.prepareStatement("INSERT INTO pet (nome, especie, raca, data_nascimento, cor, porte, idPessoa) VALUES(?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS);
           stmt.setString(1, pet.getNome());
           stmt.setString(2, pet.getEspecie());
           stmt.setString(3, pet.getRaca());
           stmt.setDate(4, pet.getData_nascimento());
           stmt.setString(5, pet.getCor());
           stmt.setString(6, pet.getPorte());
           stmt.setInt(7, pet.getPessoa().getIdPessoa());
           stmt.execute();
           ResultSet rs = stmt.getGeneratedKeys();
           if(rs.next()){
               pet.setIdPet(rs.getInt("idpet"));
           }else{
              pet.setIdPet(-1);
           }
       }catch(Exception e){
           e.printStackTrace();
       }
       
       return pet;
   }
}
