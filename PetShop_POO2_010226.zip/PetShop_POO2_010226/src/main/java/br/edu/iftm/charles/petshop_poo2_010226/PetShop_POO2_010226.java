/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package br.edu.iftm.charles.petshop_poo2_010226;

import br.edu.iftm.charles.petshop_poo2_010226.dao.PessoaDAO;
import br.edu.iftm.charles.petshop_poo2_010226.dao.PetDAO;
import br.edu.iftm.charles.petshop_poo2_010226.objetos.Pessoa;
import br.edu.iftm.charles.petshop_poo2_010226.objetos.Pet;

/**
 *
 * @author charl
 */
public class PetShop_POO2_010226 {

    public static void main(String[] args) {
        Pessoa p = new Pessoa();
        p.setNome("Teste 02-2026");
        p.setCpf("000.222.222-33");
        p.setData_nasc("2000-01-01");
        
        Pet pet = new Pet();
        pet.setNome("Pet Teste 02-2026");
        pet.setEspecie("TESTE");
        pet.setRaca("SRD");
        pet.setPorte("Grande");
        pet.setCor("Branco");
        pet.setData_nascimento("2010-01-01");
        pet.setPessoa(p);
        
        PessoaDAO pDAO = new PessoaDAO();
        PetDAO petDAO = new PetDAO();
        
        pDAO.salvar(p);
        petDAO.Salvar(pet);
    }
}
