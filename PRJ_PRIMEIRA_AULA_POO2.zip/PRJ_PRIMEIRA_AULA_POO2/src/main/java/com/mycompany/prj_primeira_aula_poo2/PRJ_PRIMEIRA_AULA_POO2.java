/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.prj_primeira_aula_poo2;

/**
 *
 * @author Iftm
 */
public class PRJ_PRIMEIRA_AULA_POO2 {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
