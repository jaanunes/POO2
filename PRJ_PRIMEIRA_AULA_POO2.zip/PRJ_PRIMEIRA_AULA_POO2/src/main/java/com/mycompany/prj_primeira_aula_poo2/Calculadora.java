/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.prj_primeira_aula_poo2;

/**
 *
 * @author Iftm
 */
public class Calculadora 
{
    public float somar(float nro1, float nro2)
    {   
        return nro1 + nro2;  
    }
    
    public float sub(float nro1, float nro2)
    {
        return nro1 - nro2;
    }
    
    public float mult(float nro1, float nro2)
    {
        return nro1 * nro2;
    }
    
    public float div(float nro1, float nro2)
    {
        return nro1 / nro2;
    }
    
}
